package com.generation.Junit2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Junit2Application {

	public static void main(String[] args) {
		SpringApplication.run(Junit2Application.class, args);
	}

}
