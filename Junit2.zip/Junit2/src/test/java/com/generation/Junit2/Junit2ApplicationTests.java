package com.generation.Junit2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Junit2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
